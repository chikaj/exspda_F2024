CREATE TABLE inclass1 (
    phrase TEXT
);

INSERT INTO inclass1 (phrase) VALUES
('     tHIS tEXT IS ALL fUnKy    ');
